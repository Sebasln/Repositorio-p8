#ifndef HISTORIA_H
#define HISTORIA_H
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void historia_inicial();

void historia_final_bueno();

void historia_final_malo();

#endif